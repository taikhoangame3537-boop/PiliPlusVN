enum PgcEpisodeType { episode, section }
