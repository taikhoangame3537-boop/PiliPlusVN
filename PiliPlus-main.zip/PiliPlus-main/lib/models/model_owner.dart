import 'package:PiliPlus/models/model_video.dart';
import 'package:PiliPlus/models_new/dynamic/dyn_mention/item.dart';
import 'package:PiliPlus/utils/parse_int.dart';
import 'package:hive_ce/hive.dart';

part 'model_owner.g.dart';

@HiveType(typeId: 3)
class Owner implements BaseOwner {
  Owner({
    this.mid,
    this.name,
    this.face,
  });
  @HiveField(0)
  @override
  int? mid;
  @HiveField(1)
  @override
  String? name;
  @HiveField(2)
  String? face;

  Owner.fromJson(Map<String, dynamic> json) {
    mid = safeToInt(json["mid"]);
    name = json["name"];
    face = json['face'];
  }

  Map<String, dynamic> toJson() => {
    'mid': mid,
    'name': name,
    'face': face,
  };

  MentionItem? get mentionItem => MentionItem(
    face: face,
    name: name,
    uid: mid.toString(),
  );
}
